Về mã nguồn:
1. Bản thân thư mục "Exercise4_Maven" là một project Maven.
2. Mã nguồn của chương trình chính nằm trong thư mục Exercise4_Maven/src/main/java/org/example/Program.java
3. Đóng gói mã nguồn thành file jar bằng lệnh "mvn package" trong command prompt của thư mục "Exercise4_Maven"
4. File jar sau khi được đóng gói mặc định sẽ nằm trong thư mục Exercise4_Maven\target

Về file jar
1. Mã nguồn khi được biên dịch sẽ xuất hiện 2 file jar do cấu hình mặc định của maven-shade-plugin nằm trong pom.xml
2. File jar chính là Program-Lab1-1.jar được dùng để chạy chương trình và file jar gốc là Lab1-1.jar
3. Chạy chương trình bằng lệnh "java -jar Program-Lab1-1.jar <liên kết>" trong command prompt của thư mục chứa file jar

Ví dụ:
java -jar Program-Lab1-1.jar
java -jar Program-Lab1-1.jar https:abc
java -jar Program-Lab1-1.jar https://stackoverflow.com/questions/45812230/maven-shade-plugin-add-application-version-to-manifest
java -jar Program-Lab1-1.jar https://images.viblo.asia/120x120/a71251ad-b3cb-4699-8964-a64e105a4c9b.png