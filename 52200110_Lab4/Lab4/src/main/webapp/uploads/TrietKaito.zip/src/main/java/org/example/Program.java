package org.example;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.validator.routines.UrlValidator;

import java.io.*;
import java.net.URL;

public class Program
{
    public static void main(String[] args) throws FileNotFoundException {
        if (args == null || args.length == 0){
            System.out.println("Please specify an URL to file");
            return;
        }
        String[] scheme = {"http", "https"};
        UrlValidator urlVal = new UrlValidator(scheme);
        if (!urlVal.isValid(args[0])){
            System.out.println("This is not a valid url");
        }
        else{
            try {
                InputStream inputStream = new URL(args[0]).openStream();
                File fileDest = new File(getNameOfUrl(args[0]));
                FileUtils.copyToFile( inputStream,  fileDest);
                System.out.println("Download file successfully.\nPath -> " + fileDest.getAbsolutePath());
            } catch (RuntimeException | IOException e) {
                System.out.println("Error: " + e.getMessage() + "\nCause: " + e.getCause());
            }
        }
    }

    private static String getNameOfUrl(String url){
        int lastSpl = url.lastIndexOf("/");
        return url.contains(".") ? url.substring(lastSpl+1)+".html" : url.substring(lastSpl+1);
    }
}