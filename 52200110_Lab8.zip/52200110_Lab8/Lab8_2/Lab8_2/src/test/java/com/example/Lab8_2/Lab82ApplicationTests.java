package com.example.Lab8_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab82ApplicationTests {

	@Test
	void contextLoads() {
	}

}
