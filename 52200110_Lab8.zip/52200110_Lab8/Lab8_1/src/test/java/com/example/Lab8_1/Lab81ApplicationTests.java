package com.example.Lab8_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab81ApplicationTests {

	@Test
	void contextLoads() {
	}

}
